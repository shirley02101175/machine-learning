#ifndef SVMCOMMONH
#define SVMCOMMONH
#include <string>


struct Kernel_params{
	float gamma;
	float coef0;
	int degree;
	float b;
	std::string kernel_type;
    float * bArray;
    int bArraySize;
    int * nrsvArray;
    int * labelArray;
    int nrClass;
};

enum SelectionHeuristic {FIRSTORDER, SECONDORDER, RANDOM, ADAPTIVE};

#endif
