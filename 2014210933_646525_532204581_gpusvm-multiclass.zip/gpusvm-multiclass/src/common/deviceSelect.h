#ifndef DEVICESELECT
#define DEVICESELECT

#include <cuda.h>
#include <cutil.h>
#include <stdio.h>


void chooseLargestGPU(bool verbose = true);

#endif
